#!/bin/bash
echo "================================================================"
echo "  Ubuntu Client DHCP Status"
echo "================================================================"
echo "Interface eth0:"
ip -brief addr show eth0 || ip addr show eth0
echo ""
echo "Default Gateway:"
ip route | grep default || echo "  (no default route assigned)"
echo ""
echo "DHCP Leases file (/var/lib/dhcp/dhclient.leases):"
tail -15 /var/lib/dhcp/dhclient.leases 2>/dev/null || echo "  (no leases recorded)"
echo "================================================================"
