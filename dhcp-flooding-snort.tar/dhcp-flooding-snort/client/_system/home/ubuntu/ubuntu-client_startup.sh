#!/bin/bash
# Startup script for ubuntu-client container (dhcp-flooding-snort)
set -e

for i in {1..10}; do
    if ip link show eth0 >/dev/null 2>&1; then
        break
    fi
    sleep 1
done

echo "[ubuntu-client] Removing placeholder static IP 10.10.0.50..."
ip addr del 10.10.0.50/24 dev eth0 2>/dev/null || true

cp "$(dirname "$0")/check_ip.sh" /home/ubuntu/check_ip.sh 2>/dev/null || true
cp "$(dirname "$0")/renew_lease.sh" /home/ubuntu/renew_lease.sh 2>/dev/null || true
cp "$(dirname "$0")/verify_connectivity.sh" /home/ubuntu/verify_connectivity.sh 2>/dev/null || true
chmod +x /home/ubuntu/*.sh
chown -R ubuntu:ubuntu /home/ubuntu

echo "[ubuntu-client] Requesting initial DHCP lease via dhclient on eth0..."
dhclient -v eth0 2>/var/log/dhclient.log || {
    echo "[ubuntu-client] Initial dhclient failed (server may still be starting). Run /home/ubuntu/renew_lease.sh in a moment."
}

echo "[ubuntu-client] Startup completed."
