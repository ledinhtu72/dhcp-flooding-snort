#!/bin/bash
echo "[*] Releasing DHCP lease on eth0..."
dhclient -r eth0 2>/dev/null || true
echo "[*] Requesting new lease on eth0..."
dhclient -v eth0
echo ""
echo "Current address:"
ip -brief addr show eth0 || ip addr show eth0
