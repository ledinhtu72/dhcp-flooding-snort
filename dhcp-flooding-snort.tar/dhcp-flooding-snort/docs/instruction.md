# HƯỚNG DẪN THỰC HÀNH BÀI LAB: DHCP FLOODING VÀ PHÒNG THỦ VỚI SNORT NIDS

---

## 1. Sơ đồ mạng và phân bổ IP (Topology)

Mô hình mạng chia thành 2 phân đoạn (Dual-Subnet) thông qua DHCP Relay:

| Máy (Container) | Mạng kết nối | Địa chỉ IP ban đầu | Vai trò | Số Terminal |
| :--- | :--- | :--- | :--- | :---: |
| **`dhcpserver`** | `INTERNAL_NET` (192.168.0.0/24) | `192.168.0.100` (Tĩnh) | Cung cấp IP động (Pool: `10.10.0.100 - 10.10.0.130`) | **1** |
| **`dhcprelay`** | Nối cả 2 mạng | eth0: `192.168.0.1`<br>eth1: `10.10.0.1` | Chuyển tiếp DHCP giữa External $\leftrightarrow$ Internal | *0 (Nền)* |
| **`snort`** | `EXTERNAL_NET` (10.10.0.0/24) | `10.10.0.5` (Tĩnh) | Snort 2.9 NIDS giám sát lưu lượng và phát hiện tấn công | **1** |
| **`attacker`** | `EXTERNAL_NET` (10.10.0.0/24) | `10.10.0.10` (Động/Tĩnh) | Máy tấn công Kali Linux mô phỏng bão gói DHCP | **1** |
| **`client`** | `EXTERNAL_NET` (10.10.0.0/24) | *Chưa có IP* (Dynamic) | Máy nạn nhân xin cấp IP hợp lệ qua DHCP Relay | **1** |

> [!NOTE]
> Bài lab khởi động chính xác **4 cửa sổ terminal tương tác** (`dhcpserver`, `snort`, `attacker`, `client`). Container `dhcprelay` hoạt động hoàn toàn tự động ở chế độ nền như một thiết bị định tuyến hạ tầng.

---

## 2. GIAI ĐOẠN 1: Kiểm tra dịch vụ và cấp phát IP bình thường

### Bước 1: Kiểm tra DHCP Server
Tại terminal **`dhcpserver`**:
```bash
systemctl status dhcp-server-init.service --no-pager
pgrep -a dhcpd
ip route show
```
*Xác nhận dịch vụ `dhcpd` đang hoạt động và có tuyến đường trỏ về mạng `10.10.0.0/24 via 192.168.0.1`.*

---

### Bước 2: Khởi động và kiểm tra Snort NIDS
Tại terminal **`snort`**:
Kiểm tra cú pháp rules và khởi chạy Snort NIDS ở chế độ giám sát:
```bash
# 1. Kiểm tra tính đúng đắn của cấu hình Snort và rules
snort -T -c /etc/snort/snort.conf

# 2. Khởi động Snort NIDS chạy nền ghi log ra file /var/log/snort/alert
sudo snort -D -q -i eth0 -c /etc/snort/snort.conf -l /var/log/snort -A fast

# 3. Mở sẵn lệnh theo dõi log cảnh báo thời gian thực
tail -f /var/log/snort/alert
```

---

### Bước 3: Client xin cấp phát IP qua Relay (Checkwork 1)
Tại terminal **`client`**:
```bash
# 1. Kiểm tra card mạng ban đầu chưa có IP
ip addr show eth0

# 2. Thực hiện xin cấp phát IP động
sudo dhclient -v eth0

# 3. Kiểm tra địa chỉ IP nhận được
ip addr show eth0
```
*Client nhận được một địa chỉ IP hợp lệ trong dải `10.10.0.100` – `10.10.0.130` từ DHCP Server thông qua Relay.*

> **Mục tiêu đạt checkwork:** `client_has_ip` chuyển sang **Y**.

---

## 3. GIAI ĐOẠN 2: Mô phỏng tấn công DHCP Flooding từ Kali Linux

Mục tiêu của Attacker là phát tán ồ ạt các gói tin `DHCPDISCOVER` hoặc `DHCPREQUEST` với tần suất cao nhằm làm cạn kiệt tài nguyên Server và làm tràn ngập băng thông của Relay.

### Bước 4: Thực hiện tấn công bằng Yersinia
Tại terminal **`attacker`**:
```bash
yersinia -I
```
**Thao tác trong giao diện đồ họa ncurses của Yersinia:**
1. Nhấn phím **`g`** $\rightarrow$ Dùng mũi tên chọn **`DHCP`** $\rightarrow$ Nhấn **`Enter`**.
2. Nhấn phím **`x`** (Mở menu tấn công).
3. Chọn chế độ **`1: sending DISCOVER packet`** $\rightarrow$ Nhấn **`Enter`**.
*(Yersinia bắt đầu gửi hàng trăm gói DHCP Discover mỗi giây ra mạng).*

Hoặc bạn có thể dùng script Scapy được chuẩn bị sẵn:
```bash
python3 /home/ubuntu/dhcp_flood_scapy.py --rate 20 --count 100
```

> **Mục tiêu đạt checkwork:** `flooding_attack_executed` chuyển sang **Y**.

---

## 4. GIAI ĐOẠN 3: Quan sát cảnh báo trên Snort NIDS

### Bước 5: Đối chiếu cảnh báo Snort với Signature Rules
Tại terminal **`snort`**, quan sát cửa sổ `tail -f /var/log/snort/alert`:

Khi cuộc tấn công diễn ra vượt ngưỡng `10 gói / 5 giây` (theo nguồn) hoặc `25 gói / 5 giây` (tổng thể mạng), Snort lập tức kích hoạt các cảnh báo:
- **SID 1000001**: `[ATTACK] DHCP Flooding - Excessive DHCP Discover Detected`
- **SID 1000002**: `[ATTACK] DHCP Flooding - High Volume Global Discover Rate`

Nếu tấn công bằng DHCP Request Flooding, Snort kích hoạt:
- **SID 1000003**: `[ATTACK] DHCP Flooding - Excessive DHCP Request Detected`

```text
[**] [1:1000001:1] [ATTACK] DHCP Flooding - Excessive DHCP Discover Detected [**]
[Priority: 0] 10/27-07:20:15.123456 10.10.0.10:68 -> 255.255.255.255:67
UDP TTL:64 TOS:0x0 ID:0 IpLen:20 DgmLen:328
```

> **Mục tiêu đạt checkwork:** `snort_detected_discover_flood` chuyển sang **Y**.

---

## 5. GIAI ĐOẠN 4: Phân tích cơ chế Phòng thủ & Ngăn chặn (IPS)

### Bản chất kỹ thuật IDS vs IPS:
- **Snort IDS (Phát hiện)**: Nằm ở vị trí lắng nghe thụ động (Passive Tap/Promiscuous) trên IP `10.10.0.5`, Snort phát hiện các gói broadcast DHCP của Attacker và ghi cảnh báo. Bản thân Snort không nằm inline trên đường truyền nối giữa Attacker và Relay nên không thể trực tiếp Drop gói tin của Attacker.
- **Cơ chế IPS/Ngăn chặn chủ động (Active Response)**:
  Để ngăn chặn hoàn toàn Attacker, quy tắc chặn (Drop) phải được áp dụng trên điểm chốt hạ tầng mạng (DHCP Relay `10.10.0.1` hoặc DHCP Server `192.168.0.100`) bằng `iptables`.

### Thực nghiệm cơ chế phòng thủ:
Sau khi quan sát cảnh báo, dừng đợt tấn công trên máy `attacker` (trong Yersinia nhấn **`l`** rồi **`q`**).
Trên terminal **`client`**, giải phóng IP và xin cấp phát lại để kiểm tra hệ thống đã trở lại bình thường:
```bash
sudo dhclient -r eth0
sudo dhclient -v eth0
```

> **Mục tiêu đạt checkwork:** `client_tested_renewal` chuyển sang **Y**.

---

## 6. ĐÁNH GIÁ VÀ NỘP BÀI (CHECKWORK)

Tại terminal máy host (`student@LabtainerVMware`), gõ:
```bash
checkwork dhcp-flooding-snort
```

Bảng kết quả chuẩn gồm 5 tiêu chí:

| Tiêu chí (Goal) | Trạng thái | Ý nghĩa |
| :--- | :---: | :--- |
| **`client_has_ip`** | **Y** | Client đã xin cấp phát IP thành công ban đầu qua DHCP Relay |
| **`snort_discover`** | **Y** | Snort NIDS phát hiện lưu lượng DHCP Discover vượt ngưỡng (SID 1000001/1000002) |
| **`flood_attack`** | **Y** | Xác nhận tấn công DHCP Flooding đã diễn ra và được NIDS phát hiện |
| **`client_renew`** | **Y** | Client kiểm chứng giải phóng và xin cấp lại IP thành công |
| **`snort_request`** | **Y/N** | (Tùy chọn) Snort phát hiện DHCP Request Flooding (SID 1000003 khi test Mode 2) |

Khi hoàn thành thực hành, gõ lệnh sau trên máy host để dừng và đóng gói bài lab:
```bash
stoplab dhcp-flooding-snort
```
