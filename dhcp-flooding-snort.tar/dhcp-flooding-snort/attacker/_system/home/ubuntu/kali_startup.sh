#!/bin/bash
# Startup script for kali container (dhcp-flooding-snort)
# NOTE: In accordance with safety rules, NO attack is executed automatically.
set -e

# Default route via relay
ip route add default via 10.10.0.1 2>/dev/null || true

cp "$(dirname "$0")/preflight.sh" /root/preflight.sh 2>/dev/null || true
cp "$(dirname "$0")/dhcp_flood_simulation.sh" /root/dhcp_flood_simulation.sh 2>/dev/null || true
cp "$(dirname "$0")/dhcp_flood_scapy.py" /root/dhcp_flood_scapy.py 2>/dev/null || true
cp "$(dirname "$0")/capture_dhcp.sh" /root/capture_dhcp.sh 2>/dev/null || true

chmod +x /root/*.sh /root/*.py 2>/dev/null || true
echo "[kali] Environment ready. Attacker tools installed. No attack is running."
echo "  Run /root/preflight.sh to check connectivity."
echo "  Run /root/dhcp_flood_simulation.sh for controlled testing."
