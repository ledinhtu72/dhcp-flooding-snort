#!/bin/bash
# Startup script for dhcp-relay container (dhcp-flooding-snort)
set -e

echo 1 > /proc/sys/net/ipv4/ip_forward
echo "[dhcp-relay] IP forwarding enabled."

for i in {1..10}; do
    if ip link show eth0 >/dev/null 2>&1 && ip link show eth1 >/dev/null 2>&1; then
        break
    fi
    sleep 1
done

pkill -9 dhcrelay 2>/dev/null || true
dhcrelay -4 -d -i eth0 -i eth1 192.168.0.100 &>/var/log/dhcrelay.log &
echo "[dhcp-relay] isc-dhcp-relay started (server: 192.168.0.100, interfaces: eth0, eth1)."
