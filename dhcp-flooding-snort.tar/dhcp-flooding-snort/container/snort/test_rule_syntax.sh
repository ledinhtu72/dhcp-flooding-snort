#!/bin/bash
echo "Testing Snort rule syntax..."
snort -T -c /etc/snort/snort.conf -i eth0
