#!/bin/bash
echo "================================================================"
echo "  Snort NIDS Status & Interface Verification"
echo "================================================================"
echo "Snort Process:"
if pgrep snort > /dev/null; then
    ps aux | grep snort | grep -v grep
    echo "  [OK] Snort daemon is ACTIVE."
else
    echo "  [FAIL] Snort daemon is NOT running!"
fi
echo ""
echo "Interface eth0 Promiscuous Mode:"
ip -d link show eth0 | grep -i promisc && echo "  [OK] eth0 is in PROMISCUOUS mode." || echo "  [WARN] eth0 promisc flag not visible."
echo ""
echo "Snort Configuration Validation:"
snort -T -c /etc/snort/snort.conf -i eth0 > /tmp/snort_test.log 2>&1
if [ $? -eq 0 ]; then
    echo "  [OK] Snort successfully validated configuration."
else
    echo "  [FAIL] Snort validation failed! Check /tmp/snort_test.log"
fi
echo ""
echo "Active Rules in /etc/snort/rules/local.rules:"
grep -v "^#" /etc/snort/rules/local.rules | grep -v "^$"
echo "================================================================"
