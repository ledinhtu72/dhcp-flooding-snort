#!/bin/bash
# =============================================================================
# view_alerts.sh – Start Snort NIDS (if needed) and watch live alerts
# =============================================================================
ALERT_FILE="/var/log/snort/alert"
CONF_FILE="/etc/snort/snort.conf"

echo "================================================================"
echo "  Snort NIDS Alert Monitor"
echo "================================================================"

# 1. Check if Snort daemon is running, start it if not
if ! pgrep -x snort >/dev/null 2>&1; then
    echo "[*] Snort daemon is NOT running. Starting Snort on eth0..."
    sudo ip link set eth0 promisc on 2>/dev/null || true
    sudo touch "$ALERT_FILE" && sudo chmod 666 "$ALERT_FILE"
    sudo snort -D -q -i eth0 -c "$CONF_FILE" -l /var/log/snort -A fast
    sleep 1
    if pgrep -x snort >/dev/null 2>&1; then
        echo "[OK] Snort daemon started successfully (PID $(pgrep -x snort))."
    else
        echo "[ERROR] Failed to start Snort daemon! Running manual foreground test:"
        sudo snort -T -c "$CONF_FILE"
        exit 1
    fi
else
    echo "[OK] Snort daemon is currently running (PID $(pgrep -x snort))."
fi

# 2. Show current alert count
sudo touch "$ALERT_FILE"
TOTAL=$(grep -c "\[\*\*\]" "$ALERT_FILE" 2>/dev/null || echo "0")
echo "Current alert count: $TOTAL"
echo ""
echo ">>> Watching live alerts in real-time ($ALERT_FILE)..."
echo ">>> (Press Ctrl+C to stop viewing - Snort will keep running in background)"
echo "----------------------------------------------------------------"
exec tail -n 10 -f "$ALERT_FILE"
